# Product requirements
Goal: salon/parlour billing as fast as a restaurant POS, managed securely from phones and computers.
Primary flow: select customer → services/products → assign staff per service → discount/tax → payment → save and share receipt.
Users: Owner, Manager, Receptionist, Staff. Default currency INR; tax configuration must be explicit and confirmed for the actual business. Do not assume a GST registration or tax rate.
Release success: staff can finish a normal bill in one screen; retries and offline sync cannot duplicate invoices; authorized devices see the same saved transactions; stock, commissions and reports reconcile to transaction records; backup restore works.
Business settings pending: salon name/logo, catalog, staff and commissions, registration/tax details, printer type and deployment preference. Use generic branding and editable defaults until supplied.

User implementation requirements incorporated in 0.2.0: complete confirmed price master before billing; automatic service pricing; daily customer queue; mid-session add-ons; live totals including configured taxes; optional zero discount; unique daily served-customer count; closed transaction daily summary; admin-only aggregates; Android client implementation. Actual offered services and prices remain owner configuration, not invented defaults.
