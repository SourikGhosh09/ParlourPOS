# Architecture and data
Current: Browser → local HTTP API → SQLite. All money is integer paise. Bill creation is transactional and idempotent by UUID. Database-generated sequential invoice number; immutable snapshot payload.
GET /api/catalog returns service id, name, category, price in paise.
GET /api/bills returns latest 200 immutable bills.
POST /api/bills accepts request_id, customer, phone, items[{id,quantity,staff}], discount, payment, paid. Server validates and returns snapshot with number, created, subtotal, total, due. Errors use {error:string}.
Target: mobile-first PWA → authenticated API → PostgreSQL. Store businesses, users, roles, services, products, customers, staff, bills, lines, payment events, stock events, bookings and audit events. Every business row must be tenant-scoped. No client price is trusted. Offline billing requires durable queue, client UUID, receipt-number policy and immutable synchronization outcome.

## 0.2 additions
POST /api/login {name,password}, POST /api/logout {}; GET /api/me.
Admin POST /api/master {services:[{id,name,category,price}],tax_bp}; tax_bp is basis points. GET /api/settings.
POST /api/tickets creates with {request_id,customer_key,customer,phone,items,discount} or updates with {id,version,...}. GET /api/tickets lists active sessions. POST /api/close {id,version,payment,paid} finalizes idempotently. The direct unauthenticated invoice creation route was removed.
GET /api/report?day=YYYY-MM-DD is admin-only. No financial aggregate is available to staff APIs. History includes individual receipts only.
New persisted tables: services, settings, users, sessions, tickets. Queue numbers reset daily; queue creation and invoice numbering are independent. Prices cannot change during active sessions. Close operations and ticket edits share a process lock. One server process supported; do not run multiple backend processes on the same database.

## Inventory API (admin only)
GET /api/inventory; POST /api/inventory {id?,version?,sku,name,unit,category,supplier,location,barcode,minimum,cost_price,sale_price,active,notes,custom}. Prices integer paise; minimum in user unit with up to three decimals. GET returns stock in user units, version and low_stock flag; stored minimum is integer thousandths.
POST /api/stock {request_id,id,delta,reason}; GET /api/stock-ledger returns latest 1000 events. Positive delta receives stock, negative consumes. No direct balance edit or hard delete. Archived items retain their ledger. Admin enforcement occurs on server.
