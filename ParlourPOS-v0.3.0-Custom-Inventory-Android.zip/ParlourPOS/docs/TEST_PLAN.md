# Validation
Automated: exact money/due, invalid financial inputs, quantities and duplicate submission. HTTP check: catalog, invoice create/read and static app.
Before release: test Android/iOS at narrow widths, keyboard access, full and partial payments, retry after lost response, concurrency, permission boundaries, tax rounding, receipt printer/PDF, offline restart and sync conflicts, restore from encrypted backup. No test success may be substituted for real device acceptance.

0.2 integration checks exercise staff report rejection (403), unauthenticated report rejection (401), staff master rejection, pre-confirmation billing block, queue 1/2, retry stability, version conflicts, add-ons, discount/tax rounding, close retries, same-phone footfall deduplication and master edit protection during active sessions. Android APK build and device tests remain open.
