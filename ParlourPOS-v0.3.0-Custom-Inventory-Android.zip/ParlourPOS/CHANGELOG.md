# Changes
## 0.1.0
Initial runnable billing foundation and development-control pack.

## 0.2.0
Authenticated admin/staff access, confirmed centralized catalog, queue and editable tickets, tax calculation, admin daily footfall/revenue/settlements, Android client source and integration checks.

## 0.3.0
Configurable inventory master, custom metadata, signed stock adjustments, immutable movement ledger, low-stock flags, archive control, server-side admin restrictions and stock regression checks.

## 0.3.1 Android test client
Fix system bar overlap using window insets (including keyboard). Hosted HTTPS address is default and auto-connects. Saved localhost default migrates to test host. Explicit server field label and select-all-on-focus simplify editing. Test application ID com.sourik.parlourpos.test allows installation alongside the prior debug APK.

## 0.4.0
Mobile-friendly service master forms replace JSON configuration. Enter prices directly in rupees; add/remove service rows and edit names/categories/prices. Same admin validation and active-ticket protections retained. Login adds Show password and trims username whitespace. Navigation wraps on narrow screens.

## 0.5.0 — Easy phone billing
Service category chips, compact service cards, optional customer/staff/payment details, quantity buttons, fixed View ticket shortcut and clearer save/finish actions. Finish first opens payment review when collapsed; tap again after checking payment to close. Daily admin report uses labeled summary cards. Existing server pricing, permissions and idempotent billing remain unchanged. Android native connection/print controls are unchanged; this update changes the hosted interface. Upload ZIP under the existing deployment filename using the v0.5 Termux helper. Nine backend regression checks and JavaScript syntax pass; physical phone acceptance pending.
