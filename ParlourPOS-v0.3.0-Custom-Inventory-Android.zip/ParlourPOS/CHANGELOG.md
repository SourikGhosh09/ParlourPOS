# Changes
## 0.1.0
Initial runnable billing foundation and development-control pack.

## 0.2.0
Authenticated admin/staff access, confirmed centralized catalog, queue and editable tickets, tax calculation, admin daily footfall/revenue/settlements, Android client source and integration checks.

## 0.3.0
Configurable inventory master, custom metadata, signed stock adjustments, immutable movement ledger, low-stock flags, archive control, server-side admin restrictions and stock regression checks.
