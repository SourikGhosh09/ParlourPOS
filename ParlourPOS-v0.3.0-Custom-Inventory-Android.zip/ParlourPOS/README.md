# ParlourPOS 0.2.0 — Queue, master, reports and Android source
Development checkpoint, not a production release.

## Start on a computer
Install Python 3.10+. Extract this folder. Run:

    python server.py --create-user owner --role admin
    python server.py --create-user reception --role staff
    python server.py

Passwords are prompted privately; use at least 10 characters. Open http://localhost:8765. Sign in as owner, open Admin reports & master, replace sample services/prices with the complete real catalog, set the correct tax rate (zero by default), and confirm the master. Billing is blocked until confirmation. Prices are entered in paise: 30000 = ₹300. No default login/password exists.

## Daily workflow
New customer → optional phone or stable customer ID → choose services → Save active ticket. A sequential queue number is assigned automatically. Reopen it from Active queue to add services or change staff/quantities/discount. Close ticket to record received payment and issue an immutable bill. Discounts default to zero. Tax is applied after the fixed-amount discount, using integer half-up paise rounding. Confirm the applicable tax configuration with your business requirements before use.

Admin reports aggregate closed tickets automatically for a selected day: invoice revenue, received payments, outstanding dues, payment-method settlements and unique customers served. Day boundaries use Asia/Kolkata, midnight to midnight; reporting uses the closing day. Queue numbers reset daily. Phone identifies repeat customers; for customers without a phone, reuse the same customer UUID shown in the ticket. Unidentified walk-ins each count separately. Names alone cannot establish unique people. Reports do not include pre-0.2 invoices that have no ticket record; old receipts remain in history.

Staff can open individual receipts needed for billing; aggregate reports are denied server-side. Recorded UPI/card/cash amounts are manual records, not payment gateway confirmations. Catalog changes are blocked while tickets are active. Conflicting ticket updates are rejected; reload from queue.

## Android
See android/README.md. Android source includes a WebView client, login, shared ticket workflow and native print/PDF action. USB evaluation connects to the same localhost server using adb reverse. This is not a standalone offline phone app. A debug APK has been compiled and its signature verified; see android/BUILD_STATUS.md. General Wi-Fi/cloud hosting, encrypted transport deployment and device acceptance remain pending.

## Data and checks
SQLite file parlour.sqlite3 is retained across upgrades. Stop the backend before copying it for a manual backup. Do not distribute that database. Run `python -m unittest discover -s tests -v`.
Seven checks cover billing math, invalid values, retries, login/report restrictions, queue ordering, add-ons, report footfall and master protection. JavaScript syntax checked. Android source compiled successfully; device testing remains pending.

## Customizable inventory — 0.3.0
Admin-only Inventory screen: create/edit unique SKUs, names, arbitrary units, categories, suppliers, storage locations, barcodes, cost/sale prices, low-stock thresholds, notes and arbitrary JSON custom fields. Archive items using Active checkbox. Search by SKU/name/category. Stock adjustments support receipts, consumption, wastage and corrections using signed quantities (three decimal places) and mandatory reasons. Movement history stores operator/time and retries cannot duplicate a movement. Stock cannot go negative. Units cannot change after any movement; create a new SKU for a new unit. Item edits use version conflicts to protect concurrent changes.
Inventory is manually managed in this checkpoint; service consumption recipes, retail billing integration, batch/expiry tracking, import/export and purchasing workflows are not implemented. Nine automated checks pass including quantity precision, retries, insufficient stock and unit protection.

## Hosted evaluation
Render runs hosted.py with an ADMIN_PASSWORD environment secret and owner login. Free test hosting uses a disposable SQLite database: data can reset on restart/redeployment. Use dummy customers only. Confirm the sample service master once signed in. This is evaluation hosting, not durable shop deployment.

## 0.4.0 usability update
Admin service master uses labeled editable rows for names, categories and rupee prices, with Add/Remove actions. Confirm & save persists the whole catalog. The server blocks changes while tickets are active. Login supports Show password. Stock/billing workflows are retained.
To update existing Render test hosting without changing its build command: rename this archive to ParlourPOS-v0.3.0-Custom-Inventory-Android.zip and replace the same file in the GitHub main branch. The archive contents are 0.4.0 despite the deployment-compatible filename. Auto-deploy is enabled. Test data may reset on deployment.
