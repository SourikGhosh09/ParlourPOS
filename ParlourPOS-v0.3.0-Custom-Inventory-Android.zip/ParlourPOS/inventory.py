"""Configurable inventory; quantities use integer thousandths of an item's unit."""
import json, uuid
from decimal import Decimal, InvalidOperation
from datetime import datetime, timezone

def init(db):
 db.executescript('''CREATE TABLE IF NOT EXISTS inventory(id INTEGER PRIMARY KEY,sku TEXT UNIQUE NOT NULL,payload TEXT NOT NULL,quantity INTEGER NOT NULL DEFAULT 0,version INTEGER NOT NULL DEFAULT 1);
 CREATE TABLE IF NOT EXISTS stock_events(id INTEGER PRIMARY KEY,request_id TEXT UNIQUE NOT NULL,item_id INTEGER NOT NULL,delta INTEGER NOT NULL,reason TEXT NOT NULL,actor TEXT NOT NULL,created TEXT NOT NULL);''')
def quantity(value):
 try:
  n=Decimal(str(value))*1000
  if not n.is_finite() or n!=n.to_integral_value() or abs(n)>10**12:raise ValueError('Quantity requires at most 3 decimal places')
  return int(n)
 except InvalidOperation:raise ValueError('Invalid quantity')
def items(db):
 return [dict(json.loads(r[2]),id=r[0],sku=r[1],stock=r[3]/1000,version=r[4],low_stock=r[3]<=json.loads(r[2])['minimum']) for r in db.execute('SELECT * FROM inventory ORDER BY sku')]
def save(db,data):
 sku=str(data.get('sku','')).strip()[:80];name=str(data.get('name','')).strip()[:120];unit=str(data.get('unit','')).strip()[:40]
 if not sku or not name or not unit:raise ValueError('SKU, name and unit are required')
 minimum=quantity(data.get('minimum',0))
 if minimum<0:raise ValueError('Minimum cannot be negative')
 custom=data.get('custom',{})
 if not isinstance(custom,dict) or len(json.dumps(custom))>10000:raise ValueError('Custom fields must be a small JSON object')
 price=data.get('sale_price',0);cost=data.get('cost_price',0)
 if any(type(x) is not int or not 0<=x<=100000000 for x in [price,cost]):raise ValueError('Prices must be non-negative integer paise')
 payload=dict(name=name,unit=unit,category=str(data.get('category',''))[:80],supplier=str(data.get('supplier',''))[:120],location=str(data.get('location',''))[:100],barcode=str(data.get('barcode',''))[:100],minimum=minimum,sale_price=price,cost_price=cost,active=bool(data.get('active',True)),notes=str(data.get('notes',''))[:2000],custom=custom)
 db.execute('BEGIN IMMEDIATE')
 if data.get('id'):
  row=db.execute('SELECT payload,version FROM inventory WHERE id=?',(data['id'],)).fetchone()
  if not row or row[1]!=data.get('version'):raise ValueError('Item changed. Reload inventory.')
  if json.loads(row[0])['unit']!=unit and db.execute('SELECT 1 FROM stock_events WHERE item_id=?',(data['id'],)).fetchone():raise ValueError('Unit cannot change after stock movements; create a new SKU.')
  db.execute('UPDATE inventory SET sku=?,payload=?,version=version+1 WHERE id=?',(sku,json.dumps(payload),data['id']))
 else:db.execute('INSERT INTO inventory(sku,payload) VALUES(?,?)',(sku,json.dumps(payload)))
 db.commit();return items(db)
def move(db,data,actor):
 rid=str(uuid.UUID(data['request_id']));delta=quantity(data['delta']);reason=str(data.get('reason','')).strip()[:300]
 if not delta or not reason:raise ValueError('Non-zero movement and reason required')
 db.execute('BEGIN IMMEDIATE')
 old=db.execute('SELECT item_id,delta,reason FROM stock_events WHERE request_id=?',(rid,)).fetchone()
 if old:
  if old!=(data['id'],delta,reason):raise ValueError('Retry ID reused with different movement')
  db.commit();return items(db)
 row=db.execute('SELECT quantity,payload FROM inventory WHERE id=?',(data['id'],)).fetchone()
 if not row or not json.loads(row[1])['active']:raise ValueError('Active item required')
 if row[0]+delta<0:raise ValueError('Insufficient stock')
 db.execute('UPDATE inventory SET quantity=quantity+?,version=version+1 WHERE id=?',(delta,data['id']))
 db.execute('INSERT INTO stock_events(request_id,item_id,delta,reason,actor,created) VALUES(?,?,?,?,?,?)',(rid,data['id'],delta,reason,actor,datetime.now(timezone.utc).isoformat()))
 db.commit();return items(db)
def ledger(db):
 return [dict(id=r[0],sku=r[1],delta=r[2]/1000,reason=r[3],actor=r[4],created=r[5]) for r in db.execute('SELECT e.id,i.sku,e.delta,e.reason,e.actor,e.created FROM stock_events e JOIN inventory i ON e.item_id=i.id ORDER BY e.id DESC LIMIT 1000')]
