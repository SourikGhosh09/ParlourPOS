# Tasks
- [x] SETUP-001: Local billing foundation.
- [x] AUTH-001A: Single-shop admin/staff login and server-enforced report permissions.
- [x] CATALOG-001A: Confirmed service master, fixed pricing, configured tax rate.
- [x] QUEUE-001: Daily sequential queue and editable active tickets with conflict checks.
- [x] REPORT-001A: Closed-ticket daily footfall, revenue, received/due and settlements.
- [x] ANDROID-001A: Android WebView client source with USB connection and printing.
- [x] ANDROID-001B-build: Compile and signature-verify debug APK.
- [ ] ANDROID-001B-device: Validate physical phone billing/printing. Next task.
- [ ] AUTH-001B: Recovery, audit, production hosting hardening and Secure cookies.
- [ ] CATALOG-001B: Friendly service/staff/settings forms, tax invoice identity.
- [ ] BILL-002: Split payments, due settlement, refunds and void audit.
- [ ] MOBILE-001: Trusted HTTPS hosting and multi-device acceptance.
- [ ] CRM-001: Full customer master and visit history.
- [ ] BOOK-001 / STAFF-001: Appointments and commissions.
- [ ] STOCK-001 / LOYALTY-001: Inventory, packages, memberships.
- [ ] REPORT-001B: Expenses and reconciled operational dashboards.
- [ ] OFFLINE-001: Durable offline queue and synchronization.
- [ ] RELEASE-001: Encrypted backups, tested restore and production acceptance.
- [x] STOCK-001A: Configurable item master, units, custom metadata, low-stock thresholds and audited stock movements.
- [ ] STOCK-001B: Service consumption recipes, retail sale integration, batch/expiry and imports/exports.
- [x] CATALOG-001B-forms: Friendly service editor with rupee prices, add/remove and categories.
- [ ] CATALOG-001B-identity: Staff master, business settings and tax invoice identity.

- [x] UI-005: Compact phone billing, optional details, quantity controls and payment review.

- [x] UI-006: UIAudit findings, mobile flow, typed inventory fields, Android toolbar and compiled test APK.
