"""Render test hosting entrypoint. Disposable evaluation database."""
import os
from pathlib import Path
import server
server.DB=Path('/tmp/parlourpos-test.sqlite3')
password=os.environ['ADMIN_PASSWORD']
with server.connect() as db: exists=db.execute('SELECT 1 FROM users WHERE name=?',('owner',)).fetchone()
if not exists:server.add_user('owner',password,'admin')
class HostedHandler(server.Handler):
 def send(self,status,body,kind='application/json',cookie=None):
  if cookie:cookie+='; Secure'
  return super().send(status,body,kind,cookie)
 def do_GET(self):
  if self.path=='/health':return self.send(200,{'ok':True})
  return super().do_GET()
server.ThreadingHTTPServer(('0.0.0.0',int(os.environ.get('PORT','10000'))),HostedHandler).serve_forever()
