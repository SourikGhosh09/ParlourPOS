# Handover — 0.2.0
Implemented requested service master confirmation, lookup/pricing, sequential daily customer queue, editable active tickets, staff per service, dynamic tax/discount totals, closed-ticket daily footfall/revenue/settlement summaries, authenticated admin report restrictions, and Android WebView client source.
Server is single-shop, localhost only. PBKDF2 passwords, 8-hour server-side cookie sessions, login throttling, JSON-only mutations, same-origin browser write checks. Create admin/staff users with the CLI. No multi-tenant system or public deployment.
SQLite schema additions preserve existing invoices. Pre-0.2 invoices are viewable but excluded from new ticket-based reports. Closed bill retries reuse deterministic UUIDs; queue insertion uses an immediate transaction; updates use version checks. Tax is aggregate exclusive tax after discount. Master updates blocked while active tickets exist.
Next: build and test Android APK with Android Studio, exercise USB connection and receipts on a real phone; then hardened HTTPS hosting, persistent connection failure recovery, backup/restore, tax identity, due settlement and split payment support. No offline billing queue yet.
Validation: seven Python unit/HTTP integration tests pass; Python and JavaScript syntax checks pass. No Android SDK or Gradle available, therefore APK compilation and device acceptance unverified.

## 0.3.0 inventory update
inventory.py adds integer-thousandth stock quantities, unique SKUs, flexible metadata and stock event ledger. Inventory endpoints are admin only. Metadata version conflict checks; stock movements transactionally reject negative balances and provide request UUID idempotency. No service/retail automatic stock deduction yet. Nine automated checks passed. Android build result documented separately in android/BUILD_STATUS.md.

Android 0.3.0 debug APK compiled successfully and passed apksigner verification. Prior 0.2 toolchain limitations are resolved. Physical device acceptance still pending.
