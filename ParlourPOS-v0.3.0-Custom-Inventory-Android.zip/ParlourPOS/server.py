"""ParlourPOS local development release. Python 3.10+, no dependencies."""
import inventory
import argparse
import hashlib, secrets, time, getpass
from http.cookies import SimpleCookie
from datetime import timedelta
from urllib.parse import urlparse, parse_qs
import json
import sqlite3
import uuid
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / 'parlour.sqlite3'
CATALOG = [dict(id=i+1, name=n, category=c, price=p) for i,(n,c,p) in enumerate([
 ('Haircut','Hair',30000),('Hair Spa','Hair',70000),('Hair Colour','Hair',120000),
 ('Facial','Face',80000),('Cleanup','Face',50000),('Manicure','Nails',40000),
 ('Nail Art','Nails',60000),('Pedicure','Nails',50000)])]

def connect():
    db=sqlite3.connect(DB, timeout=15)
    db.execute('CREATE TABLE IF NOT EXISTS bills (id INTEGER PRIMARY KEY, request_id TEXT UNIQUE NOT NULL, created TEXT NOT NULL, payload TEXT NOT NULL)')
    db.executescript("""
    CREATE TABLE IF NOT EXISTS services(id INTEGER PRIMARY KEY,name TEXT NOT NULL,category TEXT NOT NULL,price INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS users(name TEXT PRIMARY KEY,salt TEXT NOT NULL,hash TEXT NOT NULL,role TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,name TEXT NOT NULL,expires INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY,request_id TEXT UNIQUE,day TEXT NOT NULL,queue INTEGER NOT NULL,customer_key TEXT NOT NULL,payload TEXT NOT NULL,version INTEGER NOT NULL DEFAULT 1,closed INTEGER NOT NULL DEFAULT 0,UNIQUE(day,queue));
    CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY,tax_bp INTEGER NOT NULL DEFAULT 0,ready INTEGER NOT NULL DEFAULT 0);
    INSERT OR IGNORE INTO settings(id) VALUES(1);
    """)
    if not db.execute('SELECT count(*) FROM services').fetchone()[0] and not db.execute('SELECT ready FROM settings').fetchone()[0]:
        db.executemany('INSERT INTO services VALUES(?,?,?,?)',[(x['id'],x['name'],x['category'],x['price']) for x in CATALOG])
    inventory.init(db)
    db.commit()
    return db

def create_bill(data):
    request_id=str(uuid.UUID(data['request_id']))
    with connect() as db:
        old=db.execute('SELECT payload FROM bills WHERE request_id=?',(request_id,)).fetchone()
        if old: return json.loads(old[0])
        items=[]
        catalog=[dict(id=r[0],name=r[1],category=r[2],price=r[3]) for r in db.execute('SELECT * FROM services')]
        if not isinstance(data['items'],list) or not 1 <= len(data['items']) <= 100: raise ValueError('Select at least one service.')
        for line in data['items']:
            service=next((s for s in catalog if s['id']==line['id']),None)
            qty=line['quantity']
            if not service or type(qty) is not int or not 1 <= qty <= 100: raise ValueError('Invalid service quantity.')
            staff=str(line.get('staff','')).strip()[:80]
            items.append(dict(service,quantity=qty,staff=staff))
        subtotal=sum(x['price']*x['quantity'] for x in items)
        discount=data.get('discount',0)
        paid=data.get('paid',0)
        if type(discount) is not int or not 0 <= discount <= subtotal: raise ValueError('Invalid discount.')
        tax_bp=db.execute('SELECT tax_bp FROM settings WHERE id=1').fetchone()[0]
        tax=((subtotal-discount)*tax_bp+5000)//10000
        total=subtotal-discount+tax
        if type(paid) is not int or not 0 <= paid <= total: raise ValueError('Paid amount must be between zero and total.')
        payment=data.get('payment')
        if payment not in ['Cash','UPI','Card']: raise ValueError('Invalid payment method.')
        customer=str(data.get('customer','')).strip()[:100] or 'Walk-in'
        phone=str(data.get('phone','')).strip()
        if phone and (not phone.isdigit() or not 7 <= len(phone) <= 15): raise ValueError('Enter a valid phone number.')
        bill=dict(items=items,customer=customer,phone=phone,subtotal=subtotal,discount=discount,tax=tax,tax_bp=tax_bp,total=total,paid=paid,due=total-paid,payment=payment,created=datetime.now(timezone.utc).isoformat())
        cursor=db.execute('INSERT INTO bills(request_id,created,payload) VALUES (?,?,?)',(request_id,bill['created'],'{}'))
        bill['number']=f'POS-{cursor.lastrowid:06d}'
        db.execute('UPDATE bills SET payload=? WHERE id=?',(json.dumps(bill),cursor.lastrowid))
        return bill

def day(): return datetime.now(timezone(timedelta(hours=5,minutes=30))).date().isoformat()
def password_hash(password,salt): return hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt),200000).hex()
def add_user(name,password,role):
    if role not in ('admin','staff') or len(password)<10 or not name.strip(): raise ValueError('Use admin/staff role and a password of at least 10 characters.')
    salt=secrets.token_hex(16)
    with connect() as db: db.execute('INSERT INTO users VALUES(?,?,?,?)',(name,salt,password_hash(password,salt),role))

def save_ticket(data):
    rid=str(uuid.UUID(data['request_id'])) if not data.get('id') else None
    customer_key=str(uuid.UUID(data['customer_key'])) if not data.get('id') else None
    # Ticket line prices are calculated independently, using the same trusted master.
    with connect() as db:
        catalog={r[0]:dict(id=r[0],name=r[1],category=r[2],price=r[3]) for r in db.execute('SELECT * FROM services')}
    lines=data.get('items',[])
    if not isinstance(lines,list) or len(lines)>100: raise ValueError('Invalid items')
    items=[]
    for line in lines:
        if line.get('id') not in catalog or type(line.get('quantity')) is not int or not 1<=line['quantity']<=100: raise ValueError('Invalid service or quantity')
        items.append(dict(catalog[line['id']],quantity=line['quantity'],staff=str(line.get('staff',''))[:80]))
    discount=data.get('discount',0); subtotal=sum(x['price']*x['quantity'] for x in items)
    if type(discount) is not int or not 0<=discount<=subtotal: raise ValueError('Invalid discount')
    phone=str(data.get('phone','')).strip()
    if phone and (not phone.isdigit() or not 7<=len(phone)<=15): raise ValueError('Invalid phone')
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        if not db.execute('SELECT ready FROM settings WHERE id=1').fetchone()[0]:raise ValueError('Admin must confirm the service master first.')
        if data.get('id'):
            row=db.execute('SELECT payload,version,closed FROM tickets WHERE id=?',(data['id'],)).fetchone()
            if not row or row[2] or row[1]!=data.get('version'): raise ValueError('Ticket changed or closed. Reload.')
            ticket=json.loads(row[0]);ticket['version']+=1
        else:
            old=db.execute('SELECT payload FROM tickets WHERE request_id=?',(rid,)).fetchone()
            if old:return json.loads(old[0])
            queue=db.execute('SELECT COALESCE(MAX(queue),0)+1 FROM tickets WHERE day=?',(day(),)).fetchone()[0]
            cur=db.execute('INSERT INTO tickets(request_id,day,queue,customer_key,payload) VALUES(?,?,?,?,?)',(rid,day(),queue,customer_key,'{}'))
            ticket=dict(id=cur.lastrowid,queue=queue,day=day(),customer_key=customer_key,version=1,closed=False)
        tax_bp=db.execute('SELECT tax_bp FROM settings WHERE id=1').fetchone()[0];tax=((subtotal-discount)*tax_bp+5000)//10000
        ticket.update(customer=str(data.get('customer','Walk-in'))[:100] or 'Walk-in',phone=phone,items=items,discount=discount,subtotal=subtotal,tax=tax,total=subtotal-discount+tax)
        db.execute('UPDATE tickets SET payload=?,version=? WHERE id=?',(json.dumps(ticket),ticket['version'],ticket['id']))
        return ticket

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def send(self,status,body,kind='application/json',cookie=None):
        raw=json.dumps(body).encode() if kind=='application/json' else body
        self.send_response(status)
        self.send_header('Content-Type',kind);self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(raw)));self.send_header('X-Content-Type-Options','nosniff')
        if cookie:self.send_header('Set-Cookie',cookie)
        self.end_headers();self.wfile.write(raw)
    def user(self):
        cookie=SimpleCookie(self.headers.get('Cookie',''));token=cookie.get('session')
        if not token:return None
        with connect() as db:return db.execute('SELECT users.name,role FROM sessions JOIN users ON sessions.name=users.name WHERE token=? AND expires>?',(token.value,time.time())).fetchone()
    def do_GET(self):
        path=urlparse(self.path).path
        if path in ('/','/app.js','/style.css'):
            name={'/':'index.html','/app.js':'app.js','/style.css':'style.css'}[path]
            return self.send(200,(ROOT/name).read_bytes(),{'/':'text/html','/app.js':'text/javascript','/style.css':'text/css'}[path])
        user=self.user()
        if not user:return self.send(401,{'error':'Login required'})
        with connect() as db:
            if path in ('/api/inventory','/api/stock-ledger'):
                if user[1]!='admin':return self.send(403,{'error':'Admin only'})
                return self.send(200,inventory.items(db) if path=='/api/inventory' else inventory.ledger(db))
            if path=='/api/me':return self.send(200,dict(name=user[0],role=user[1]))
            if path=='/api/catalog':return self.send(200,[dict(id=r[0],name=r[1],category=r[2],price=r[3]) for r in db.execute('SELECT * FROM services')])
            if path=='/api/settings':return self.send(200,dict(zip(('tax_bp','ready'),db.execute('SELECT tax_bp,ready FROM settings').fetchone())))
            if path=='/api/tickets':return self.send(200,[json.loads(r[0]) for r in db.execute('SELECT payload FROM tickets WHERE closed=0 ORDER BY id')])
            if path=='/api/bills':return self.send(200,[json.loads(r[0]) for r in db.execute('SELECT payload FROM bills ORDER BY id DESC LIMIT 200')])
            if path=='/api/report':
                if user[1]!='admin':return self.send(403,{'error':'Admin only'})
                date=parse_qs(urlparse(self.path).query).get('day',[day()])[0]
                try:datetime.strptime(date,'%Y-%m-%d')
                except ValueError:return self.send(400,{'error':'Invalid day'})
                rows=[json.loads(r[0]) for r in db.execute('SELECT payload FROM tickets WHERE closed=1')]
                rows=[x for x in rows if x.get('closed_day',x['day'])==date]
                settlement={k:sum(x['bill']['paid'] for x in rows if x['bill']['payment']==k) for k in ('Cash','UPI','Card')}
                return self.send(200,dict(day=date,footfall=len({x['phone'] or x['customer_key'] for x in rows}),closed_tickets=len(rows),revenue=sum(x['bill']['total'] for x in rows),received=sum(settlement.values()),due=sum(x['bill']['due'] for x in rows),settlement=settlement))
        self.send(404,{'error':'Not found'})
    def do_POST(self):
        origin=self.headers.get('Origin')
        if origin and urlparse(origin).netloc!=self.headers.get('Host'):return self.send(403,{'error':'Origin rejected'})
        if self.headers.get('Content-Type')!='application/json':return self.send(415,{'error':'JSON required'})
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=100000:raise ValueError('Invalid request size')
            data=json.loads(self.rfile.read(length))
            if self.path=='/api/login':
                now=time.time();key=self.client_address[0];attempts=LOGIN_ATTEMPTS.setdefault(key,[]);attempts[:]=[x for x in attempts if now-x<300]
                if len(attempts)>=10:return self.send(429,{'error':'Wait five minutes before retrying'})
                attempts.append(now)
                with connect() as db:
                    row=db.execute('SELECT salt,hash,role FROM users WHERE name=?',(str(data.get('name','')),)).fetchone()
                    if not row or not secrets.compare_digest(row[1],password_hash(str(data.get('password','')),row[0])):return self.send(401,{'error':'Invalid login'})
                    token=secrets.token_hex(32);db.execute('INSERT INTO sessions VALUES(?,?,?)',(token,data['name'],int(now)+28800))
                return self.send(200,dict(role=row[2]),cookie='session='+token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800')
            user=self.user()
            if not user:return self.send(401,{'error':'Login required'})
            if self.path=='/api/logout':
                cookie=SimpleCookie(self.headers.get('Cookie',''))
                with connect() as db:db.execute('DELETE FROM sessions WHERE token=?',(cookie['session'].value,))
                return self.send(200,{},cookie='session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0')
            if self.path in ('/api/inventory','/api/stock'):
                if user[1]!='admin':return self.send(403,{'error':'Admin only'})
                with connect() as db:return self.send(200,inventory.save(db,data) if self.path=='/api/inventory' else inventory.move(db,data,user[0]))
            if self.path=='/api/master':
                if user[1]!='admin':return self.send(403,{'error':'Admin only'})
                services=data['services'];tax=data.get('tax_bp',0)
                if type(tax) is not int or not 0<=tax<=10000 or not isinstance(services,list) or not 1<=len(services)<=500:raise ValueError('Invalid master')
                ids=set()
                for x in services:
                    if type(x['id']) is not int or x['id']<=0 or x['id'] in ids or not str(x['name']).strip() or type(x['price']) is not int or not 0<=x['price']<=100000000:raise ValueError('Invalid service')
                    ids.add(x['id'])
                with connect() as db:
                    if db.execute('SELECT count(*) FROM tickets WHERE closed=0').fetchone()[0]:raise ValueError('Close active tickets before changing the price master')
                    db.execute('DELETE FROM services');db.executemany('INSERT INTO services VALUES(?,?,?,?)',[(x['id'],str(x['name'])[:100],str(x.get('category','Services'))[:80],x['price']) for x in services]);db.execute('UPDATE settings SET tax_bp=?,ready=1 WHERE id=1',(tax,))
                return self.send(200,{'ok':True})
            if self.path=='/api/tickets':
                with CLOSE_LOCK:return self.send(200,save_ticket(data))
            if self.path=='/api/close':
                # Serialize close operations so the ticket cannot change during finalization.
                with CLOSE_LOCK:
                    with connect() as db:row=db.execute('SELECT payload,version,closed FROM tickets WHERE id=?',(data['id'],)).fetchone()
                    if not row:raise ValueError('Ticket not found')
                    ticket=json.loads(row[0])
                    if row[2]:return self.send(200,ticket['bill'])
                    if row[1]!=data['version']:raise ValueError('Ticket changed. Reload.')
                    bill=create_bill(dict(ticket,request_id=str(uuid.uuid5(uuid.NAMESPACE_URL,'parlour-ticket-'+str(ticket['id']))),payment=data['payment'],paid=data['paid']))
                    ticket.update(closed=True,bill=bill,closed_day=day())
                    with connect() as db:db.execute('UPDATE tickets SET closed=1,payload=? WHERE id=?',(json.dumps(ticket),ticket['id']))
                    return self.send(200,bill)
            self.send(404,{'error':'Not found'})
        except (ValueError,KeyError,TypeError,AttributeError) as error:self.send(400,{'error':str(error) or 'Invalid request'})
        except sqlite3.IntegrityError:self.send(400,{'error':'SKU or identifier already exists'})
        except sqlite3.Error:self.send(503,{'error':'Database unavailable. Retry the same action.'})

import threading
CLOSE_LOCK=threading.RLock()
LOGIN_ATTEMPTS={}
if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--create-user');parser.add_argument('--role',choices=['admin','staff'],default='admin')
    args=parser.parse_args()
    if args.create_user:
        add_user(args.create_user,getpass.getpass('Password (10+ characters): '),args.role);print('User created');raise SystemExit
    with connect(): pass
    print(f'ParlourPOS preview: http://localhost:{args.port} (Ctrl+C to stop)')
    ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
