# Android client source — 0.3.0
Android WebView client uses the same authenticated server, service master, tickets and reports. It does not contain an independent billing database and cannot bill without a server connection.

## Build and run
Open this android folder in Android Studio. Use JDK 17, Android SDK 35, Android Gradle Plugin 8.7.3 and Gradle 8.9. If prompted to create a Gradle wrapper, select 8.9. Sync and build a debug APK using Build > Build App Bundle(s) / APK(s) > Build APK(s).
See BUILD_STATUS.md for the APK build result. Physical device testing remains pending.

## USB evaluation on your Android phone
1. Create a user and start the Python backend on your computer (see main README).
2. Enable Android developer options and USB debugging. Connect phone to the computer.
3. Run `adb reverse tcp:8765 tcp:8765` from Android SDK platform-tools.
4. Install the debug APK. Enter `http://localhost:8765`, tap Connect, and sign in.
5. Configure/confirm the service master as admin, then create tickets.
6. Open a receipt before using the native Print / Save PDF button.

The debug configuration permits HTTP only to localhost/127.0.0.1. Release requires a trusted HTTPS endpoint. TLS failures are rejected; no JavaScript bridge or file access is enabled. General Wi-Fi/cloud deployment, APK signing, offline synchronization and Play Store publication remain unfinished.

## 0.3.1 test client
Install ParlourPOS Test. It opens https://parlourpos-test.onrender.com automatically. The labeled server address field sits below system bars; tapping it selects the address for replacement. This separate test package does not require uninstalling the prior debug app. Same hosted login applies. The backend remains a disposable test instance.
