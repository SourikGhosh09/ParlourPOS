# Android build verification — 0.3.0
Successful Gradle assembleDebug using JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, SDK 35. Debug-signed installable APK produced; apksigner verification passed. Application com.sourik.parlourpos, version 0.3.0, minimum Android 8.0 (API 26).
Physical phone installation, printing, navigation and USB-server acceptance remain untested. This APK is a connected Android client, not a standalone offline billing app. Use adb reverse with the Python backend for the supported debug evaluation flow. A production HTTPS server and release signing remain future work.
