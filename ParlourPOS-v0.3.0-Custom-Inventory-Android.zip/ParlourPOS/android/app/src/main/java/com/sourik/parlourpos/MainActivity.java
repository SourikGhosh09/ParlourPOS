package com.sourik.parlourpos;
import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.webkit.*;
import android.widget.*;
import android.print.PrintManager;
import android.view.ViewGroup;

public class MainActivity extends Activity {
 private WebView web;
 private String origin;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);
  EditText address=new EditText(this);address.setSingleLine(true);address.setHint("HTTPS server URL or http://localhost:8765 (USB debug)");
  address.setText(getPreferences(0).getString("server","http://localhost:8765"));
  Button connect=new Button(this);connect.setText("Connect to salon server");
  Button print=new Button(this);print.setText("Print / Save PDF");
  web=new WebView(this);
  web.getSettings().setJavaScriptEnabled(true);
  web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(false);
  web.getSettings().setAllowContentAccess(false);
  web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return !sameOrigin(request.getUrl());}
   @Override public void onReceivedSslError(WebView view,android.webkit.SslErrorHandler handler,android.net.http.SslError error){handler.cancel();Toast.makeText(MainActivity.this,"TLS certificate error. Connection blocked.",Toast.LENGTH_LONG).show();}
  });
  connect.setOnClickListener(v->{
   try {
    Uri uri=Uri.parse(address.getText().toString().trim());
    String host=uri.getHost();String scheme=uri.getScheme();
    if(host==null || uri.getUserInfo()!=null || !("https".equals(scheme) || ("http".equals(scheme) && ("localhost".equals(host)||"127.0.0.1".equals(host)))))throw new IllegalArgumentException();
    origin=scheme+"://"+uri.getEncodedAuthority();
    getPreferences(0).edit().putString("server",origin).apply();web.loadUrl(origin+"/");
   }catch(Exception e){Toast.makeText(this,"Enter a valid HTTPS server URL",Toast.LENGTH_LONG).show();}
  });
  print.setOnClickListener(v->{PrintManager manager=(PrintManager)getSystemService(PRINT_SERVICE);manager.print("ParlourPOS receipt",web.createPrintDocumentAdapter("ParlourPOS"),null);});
  layout.addView(address);layout.addView(connect);layout.addView(print);layout.addView(web,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));setContentView(layout);
 }
 private boolean sameOrigin(Uri uri){return origin!=null && origin.equals(uri.getScheme()+"://"+uri.getEncodedAuthority());}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
