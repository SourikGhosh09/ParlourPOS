package com.sourik.parlourpos;
import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.net.Uri;
import android.webkit.*;
import android.widget.*;
import android.print.PrintManager;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.graphics.Insets;
import android.os.Build;
import android.content.res.Configuration;
import android.graphics.Color;

public class MainActivity extends Activity {
 private WebView web;
 private String origin;
 private LinearLayout errorPanel;
 private ProgressBar loading;
 private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  boolean dark=(getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
  int surface=Color.parseColor(dark?"#232027":"#FFFFFF"),ink=Color.parseColor(dark?"#F4EDF6":"#29232F");
  LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setBackgroundColor(surface);
  layout.setOnApplyWindowInsetsListener((view,insets)->{
   if(Build.VERSION.SDK_INT>=30){Insets bars=insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());view.setPadding(bars.left,bars.top,bars.right,bars.bottom);}
   else{view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());}
   return insets;
  });
  LinearLayout toolbar=new LinearLayout(this);toolbar.setGravity(android.view.Gravity.CENTER_VERTICAL);toolbar.setPadding(dp(12),dp(4),dp(8),dp(4));
  TextView title=new TextView(this);title.setText("Salon desk");title.setTextSize(16);title.setTextColor(ink);toolbar.addView(title,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
  Button print=new Button(this);print.setText("Print");print.setTextSize(14);print.setMinHeight(dp(48));print.setContentDescription("Print receipt or save PDF");toolbar.addView(print);
  Button settings=new Button(this);settings.setText("Server");settings.setTextSize(14);settings.setMinHeight(dp(48));settings.setContentDescription("Salon server settings");toolbar.addView(settings);layout.addView(toolbar);
  loading=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);loading.setMax(100);layout.addView(loading,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(3)));
  errorPanel=new LinearLayout(this);errorPanel.setOrientation(LinearLayout.VERTICAL);errorPanel.setPadding(dp(16),dp(12),dp(16),dp(12));
  TextView error=new TextView(this);error.setText("Cannot connect to the salon server. Check your internet or server address, then retry.");error.setTextColor(ink);error.setTextSize(16);errorPanel.addView(error);
  Button retry=new Button(this);retry.setText("Retry connection");retry.setMinHeight(dp(48));errorPanel.addView(retry);errorPanel.setVisibility(android.view.View.GONE);layout.addView(errorPanel);
  web=new WebView(this);web.setBackgroundColor(surface);
  web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
  web.setWebChromeClient(new WebChromeClient(){@Override public void onProgressChanged(WebView view,int progress){loading.setProgress(progress);loading.setVisibility(progress<100?android.view.View.VISIBLE:android.view.View.INVISIBLE);}});
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return !sameOrigin(request.getUrl());}
   @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){if(request.isForMainFrame())errorPanel.setVisibility(android.view.View.VISIBLE);}
   @Override public void onReceivedSslError(WebView view,android.webkit.SslErrorHandler handler,android.net.http.SslError error){handler.cancel();errorPanel.setVisibility(android.view.View.VISIBLE);Toast.makeText(MainActivity.this,"Certificate error. Check the server address.",Toast.LENGTH_LONG).show();}
  });
  settings.setOnClickListener(v->{
   EditText address=new EditText(this);address.setSingleLine(true);address.setText(origin);address.setSelectAllOnFocus(true);address.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
   LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(24),dp(8),dp(24),0);
   TextView label=new TextView(this);label.setText("Salon server address (HTTPS)");label.setLabelFor(android.view.View.generateViewId());address.setId(label.getLabelFor());form.addView(label);form.addView(address);
   AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Connect to salon").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Connect",null).create();dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b->{if(connect(address.getText().toString().trim()))dialog.dismiss();else address.setError("Enter a valid HTTPS address");}));dialog.show();
  });
  print.setOnClickListener(v->{PrintManager manager=(PrintManager)getSystemService(PRINT_SERVICE);manager.print("ParlourPOS receipt",web.createPrintDocumentAdapter("ParlourPOS"),null);});
  retry.setOnClickListener(v->{errorPanel.setVisibility(android.view.View.GONE);web.reload();});
  layout.addView(web,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));setContentView(layout);layout.requestApplyInsets();
  String saved=getPreferences(0).getString("server","https://parlourpos-test.onrender.com");
  if(saved.equals("http://localhost:8765")||saved.equals("http://127.0.0.1:8765"))saved="https://parlourpos-test.onrender.com";
  if(!connect(saved))connect("https://parlourpos-test.onrender.com");
 }
 private boolean connect(String address){
  try{Uri uri=Uri.parse(address);String host=uri.getHost(),scheme=uri.getScheme();
   if(host==null||uri.getUserInfo()!=null||!("https".equals(scheme)||("http".equals(scheme)&&("localhost".equals(host)||"127.0.0.1".equals(host)))))return false;
   origin=scheme+"://"+uri.getEncodedAuthority();getPreferences(0).edit().putString("server",origin).apply();errorPanel.setVisibility(android.view.View.GONE);web.loadUrl(origin+"/");return true;
  }catch(Exception e){return false;}
 }
 private boolean sameOrigin(Uri uri){return origin!=null&&origin.equals(uri.getScheme()+"://"+uri.getEncodedAuthority());}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
