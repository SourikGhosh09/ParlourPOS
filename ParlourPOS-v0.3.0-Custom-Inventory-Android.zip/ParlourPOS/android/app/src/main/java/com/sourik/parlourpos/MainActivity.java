package com.sourik.parlourpos;
import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.webkit.*;
import android.widget.*;
import android.print.PrintManager;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.graphics.Insets;
import android.os.Build;

public class MainActivity extends Activity {
 private WebView web;
 private String origin;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);
  layout.setOnApplyWindowInsetsListener((view,insets)->{
   if(Build.VERSION.SDK_INT>=30){Insets bars=insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());view.setPadding(bars.left,bars.top,bars.right,bars.bottom);}
   else{view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());}
   return insets;
  });
  TextView label=new TextView(this);label.setText("Salon server address");label.setPadding(16,12,16,4);layout.addView(label);
  EditText address=new EditText(this);address.setSingleLine(true);address.setHint("HTTPS server URL or http://localhost:8765 (USB debug)");
  String saved=getPreferences(0).getString("server","https://parlourpos-test.onrender.com");
  if(saved.equals("http://localhost:8765")||saved.equals("http://127.0.0.1:8765"))saved="https://parlourpos-test.onrender.com";
  address.setText(saved);address.setSelectAllOnFocus(true);address.setMinHeight(56);
  Button connect=new Button(this);connect.setText("Connect to salon server");
  Button print=new Button(this);print.setText("Print / Save PDF");
  web=new WebView(this);
  web.getSettings().setJavaScriptEnabled(true);
  web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(false);
  web.getSettings().setAllowContentAccess(false);
  web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return !sameOrigin(request.getUrl());}
   @Override public void onReceivedSslError(WebView view,android.webkit.SslErrorHandler handler,android.net.http.SslError error){handler.cancel();Toast.makeText(MainActivity.this,"TLS certificate error. Connection blocked.",Toast.LENGTH_LONG).show();}
  });
  connect.setOnClickListener(v->{
   try {
    Uri uri=Uri.parse(address.getText().toString().trim());
    String host=uri.getHost();String scheme=uri.getScheme();
    if(host==null || uri.getUserInfo()!=null || !("https".equals(scheme) || ("http".equals(scheme) && ("localhost".equals(host)||"127.0.0.1".equals(host)))))throw new IllegalArgumentException();
    origin=scheme+"://"+uri.getEncodedAuthority();
    getPreferences(0).edit().putString("server",origin).apply();web.loadUrl(origin+"/");
   }catch(Exception e){Toast.makeText(this,"Enter a valid HTTPS server URL",Toast.LENGTH_LONG).show();}
  });
  print.setOnClickListener(v->{PrintManager manager=(PrintManager)getSystemService(PRINT_SERVICE);manager.print("ParlourPOS receipt",web.createPrintDocumentAdapter("ParlourPOS"),null);});
  layout.addView(address);layout.addView(connect);layout.addView(print);layout.addView(web,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));setContentView(layout);layout.requestApplyInsets();connect.performClick();
 }
 private boolean sameOrigin(Uri uri){return origin!=null && origin.equals(uri.getScheme()+"://"+uri.getEncodedAuthority());}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
