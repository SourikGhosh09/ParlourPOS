import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import server,inventory
class InventoryTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();server.DB=Path(self.tmp.name)/'test.db'
 def tearDown(self):self.tmp.cleanup()
 def test_custom_stock_retry_and_protection(self):
  data=dict(sku='SHAMPOO',name='Shampoo',unit='ml',minimum='10.5',custom={'brand':'Custom'},cost_price=100,sale_price=200)
  with server.connect() as db:rows=inventory.save(db,data)
  item=rows[0];self.assertEqual(item['custom'],{'brand':'Custom'})
  move=dict(request_id='e006d233-23b3-40fd-a479-fdb5c386a3e3',id=item['id'],delta='20.125',reason='Opening stock')
  with server.connect() as db:inventory.move(db,move,'owner')
  with server.connect() as db:rows=inventory.move(db,move,'owner');self.assertEqual(rows[0]['stock'],20.125);self.assertEqual(len(inventory.ledger(db)),1)
  with self.assertRaises(ValueError):
   with server.connect() as db:inventory.move(db,dict(move,request_id='e006d233-23b3-40fd-a479-fdb5c386a3e4',delta='-21'),'owner')
  with self.assertRaises(ValueError):
   with server.connect() as db:inventory.save(db,dict(data,id=item['id'],version=rows[0]['version'],unit='bottle'))
  with self.assertRaises(ValueError):inventory.quantity('0.0001')
  with self.assertRaises(ValueError):inventory.quantity('NaN')
if __name__=='__main__':unittest.main()
