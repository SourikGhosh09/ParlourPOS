import sys,tempfile,unittest,threading,json,urllib.request,urllib.error,http.cookiejar,uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import server
class SessionTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();server.DB=Path(self.tmp.name)/'test.db';server.LOGIN_ATTEMPTS.clear()
  server.add_user('owner','secure-pass-123','admin');server.add_user('staff','secure-pass-456','staff')
  self.srv=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler);threading.Thread(target=self.srv.serve_forever,daemon=True).start();self.url=f'http://127.0.0.1:{self.srv.server_port}'
  self.admin=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));self.staff=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
  self.call(self.admin,'login',dict(name='owner',password='secure-pass-123'));self.call(self.staff,'login',dict(name='staff',password='secure-pass-456'))
 def tearDown(self):self.srv.shutdown();self.srv.server_close();self.tmp.cleanup()
 def call(self,client,path,data=None):
  req=urllib.request.Request(self.url+'/api/'+path,None if data is None else json.dumps(data).encode(),{'Content-Type':'application/json'})
  return json.load(client.open(req))
 def master(self):self.call(self.admin,'master',dict(services=server.CATALOG,tax_bp=1800))
 def ticket(self,phone='9876543210'):
  return dict(request_id=str(uuid.uuid4()),customer_key=str(uuid.uuid4()),customer='Customer',phone=phone,items=[dict(id=1,quantity=1)],discount=0)
 def test_admin_visibility(self):
  with self.assertRaises(urllib.error.HTTPError) as e:self.call(self.staff,'report')
  self.assertEqual(e.exception.code,403)
  with self.assertRaises(urllib.error.HTTPError):self.call(urllib.request.build_opener(),'report')
  with self.assertRaises(urllib.error.HTTPError):self.call(self.staff,'master',dict(services=server.CATALOG))
 def test_queue_addons_report_retry(self):
  data=self.ticket()
  with self.assertRaises(urllib.error.HTTPError):self.call(self.staff,'tickets',data)
  self.master();a=self.call(self.staff,'tickets',data);again=self.call(self.staff,'tickets',data);self.assertEqual(a,again)
  b=self.call(self.staff,'tickets',self.ticket());self.assertEqual((a['queue'],b['queue']),(1,2))
  update=dict(data,id=a['id'],version=a['version'],items=[dict(id=1,quantity=2)],discount=5000)
  a=self.call(self.staff,'tickets',update);self.assertEqual((a['total'],a['tax']),(64900,9900))
  with self.assertRaises(urllib.error.HTTPError):self.call(self.staff,'tickets',update)
  for t in [a,b]:
   close=dict(id=t['id'],version=t['version'],paid=t['total'],payment='UPI');bill=self.call(self.staff,'close',close);self.assertEqual(bill,self.call(self.staff,'close',close))
  r=self.call(self.admin,'report');self.assertEqual((r['footfall'],r['closed_tickets'],r['revenue'],r['received']),(1,2,100300,100300))
  with self.assertRaises(urllib.error.HTTPError):self.call(self.staff,'tickets',dict(update,version=a['version']))
 def test_inventory_admin_only(self):
  for path in ['inventory','stock-ledger']:
   with self.assertRaises(urllib.error.HTTPError) as e:self.call(self.staff,path)
   self.assertEqual(e.exception.code,403)
  with self.assertRaises(urllib.error.HTTPError) as e:self.call(self.staff,'stock',{})
  self.assertEqual(e.exception.code,403)
 def test_master_locked_during_session(self):
  self.master();self.call(self.staff,'tickets',self.ticket())
  with self.assertRaises(urllib.error.HTTPError):self.master()
if __name__=='__main__':unittest.main()
