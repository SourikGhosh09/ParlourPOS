import sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import server
class BillingTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); server.DB=Path(self.tmp.name)/'test.db'
  self.data=dict(request_id='e006d233-23b3-40fd-a479-fdb5c386a3e3',items=[dict(id=1,quantity=2,staff='Riya')],discount=5000,paid=40000,payment='UPI',customer='Test',phone='9876543210')
 def tearDown(self): self.tmp.cleanup()
 def test_money_and_due(self):
  b=server.create_bill(self.data); self.assertEqual((b['total'],b['due']),(55000,15000))
 def test_retry_does_not_duplicate(self):
  a=server.create_bill(self.data); b=server.create_bill(self.data); self.assertEqual(a,b)
  with server.connect() as db: self.assertEqual(db.execute('SELECT count(*) FROM bills').fetchone()[0],1)
 def test_bad_values_leave_no_bill(self):
  for field,value in [('discount',70000),('paid',60000),('paid',-1),('payment','Other'),('phone','abc')]:
   with self.assertRaises(ValueError): server.create_bill(dict(self.data,**{field:value}))
  with server.connect() as db: self.assertEqual(db.execute('SELECT count(*) FROM bills').fetchone()[0],0)
 def test_quantity_validation(self):
  for qty in [0,-1,1.5,True,101]:
   with self.assertRaises(ValueError): server.create_bill(dict(self.data,items=[dict(id=1,quantity=qty)]))
if __name__=='__main__': unittest.main()
